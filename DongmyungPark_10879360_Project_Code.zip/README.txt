==================================================
NPC Dialogue System & Game Project
==================================================

■ Development Environment
- Engine Version: Unreal Engine 5.4.4

■ Full Game Download & Installation
This submitted ZIP file contains the core logic and essential assets. 
To play the full version of the game, please download the complete project from the Google Drive link below.

* Full Game Download Link: [https://drive.google.com/file/d/1qsdGAzKU3myKQVk04MfW-EngDHKKAqmW/view?usp=sharing]

[How to Run the Game]
1. Download the full project ZIP file from the Google Drive link and extract it.
2. Open the extracted folder and double-click the `NPC.uproject` file.
3. (IMPORTANT) If a prompt appears saying "Missing NPC Modules" or "Would you like to rebuild them now?", please make sure to click [Yes]. The engine will automatically rebuild the code to match your local environment.

■ Key Bindings & Controls

[Basic Movement & Actions]
- W, A, S, D : Move
- Left Shift : Dash (Sprint)
- V : Toggle Camera Perspective (1st/3rd Person)
- E : Interact / Pick up item
- I : Open Inventory

[Dialogue & NPC Interaction]
While in the dialogue UI, use the following keys:
- R : Talk again (Continue conversation)
- E : Close dialogue UI
- T : Trade (Open shop)
- F : Request to Follow / Stop Following

==================================================